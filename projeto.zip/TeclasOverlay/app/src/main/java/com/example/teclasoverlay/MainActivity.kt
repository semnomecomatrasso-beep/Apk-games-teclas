package com.example.teclasoverlay

import android.Manifest
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("cfg", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        showHome()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(24), dp(48), dp(24), dp(24))
    }

    private fun btn(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }

    private fun showHome() {
        val l = base()
        l.addView(TextView(this).apply { text = "Teclas WASD"; textSize = 26f; gravity = Gravity.CENTER })
        l.addView(btn("▶ Iniciar") { start() })
        l.addView(btn("■ Parar") { stopService(Intent(this, OverlayService::class.java)) })
        l.addView(btn("⚙ Configurações") { showSettings() })
        setContentView(l)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Ative \"Exibir sobre outros apps\" e volte aqui", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "Teclas ativas! Pode abrir o jogo.", Toast.LENGTH_SHORT).show()
    }

    private fun showSettings() {
        val l = base()
        l.addView(TextView(this).apply { text = "Configurações"; textSize = 24f; gravity = Gravity.CENTER })
        l.addView(TextView(this).apply { text = "\nCor da tecla ao pressionar:" })

        val cores = listOf(
            "Branco" to Color.WHITE,
            "Vermelho" to Color.RED,
            "Verde" to Color.GREEN,
            "Azul" to Color.rgb(0, 120, 255),
            "Amarelo" to Color.YELLOW,
            "Roxo" to Color.rgb(170, 60, 255)
        )
        cores.chunked(3).forEach { grupo ->
            val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            grupo.forEach { (nome, cor) ->
                val b = Button(this).apply {
                    text = nome
                    setBackgroundColor(cor)
                    setTextColor(Color.BLACK)
                    setOnClickListener {
                        prefs.edit().putInt("color", cor).apply()
                        Toast.makeText(this@MainActivity, "Cor: $nome", Toast.LENGTH_SHORT).show()
                    }
                }
                linha.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            }
            l.addView(linha)
        }

        l.addView(Switch(this).apply {
            text = "Arrastar pela tela"
            setPadding(0, dp(24), 0, dp(8))
            isChecked = prefs.getBoolean("drag", false)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("drag", v).apply() }
        })
        l.addView(Switch(this).apply {
            text = "RGB ao clicar"
            setPadding(0, dp(8), 0, dp(24))
            isChecked = prefs.getBoolean("rgb", false)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("rgb", v).apply() }
        })
        l.addView(btn("← Voltar") { showHome() })
        setContentView(l)
    }
}
