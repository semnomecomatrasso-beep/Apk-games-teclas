package com.example.teclasoverlay

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var params: WindowManager.LayoutParams
    private var root: LinearLayout? = null
    private var handle: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val normal = Color.argb(200, 30, 30, 30)

    private val prefListener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> updateHandle() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        startAsForeground()
        buildOverlay()
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
    }

    private fun startAsForeground() {
        val canal = "teclas_overlay"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(canal, "Teclas WASD", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, canal)
            .setContentTitle("Teclas WASD ativas")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f

    private val dragListener = View.OnTouchListener { _, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                startX = params.x; startY = params.y
                touchX = e.rawX; touchY = e.rawY
            }
            MotionEvent.ACTION_MOVE -> {
                params.x = startX + (e.rawX - touchX).toInt()
                params.y = startY + (e.rawY - touchY).toInt()
                root?.let { wm.updateViewLayout(it, params) }
            }
        }
        true
    }

    private fun buildOverlay() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            clipChildren = false
            clipToPadding = false
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val h = TextView(this).apply {
            text = "☰ arrastar"
            textSize = 11f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.argb(140, 0, 0, 0))
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        handle = h
        h.setOnTouchListener(dragListener)
        col.addView(
            h,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
        col.addView(row(listOf("W")))
        col.addView(row(listOf("A", "S", "D")))

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(40)
            y = dp(200)
        }
        root = col
        updateHandle()
        wm.addView(col, params)
    }

    private fun row(labels: List<String>): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        clipChildren = false
        labels.forEach { addView(makeKey(it)) }
    }

    private fun updateHandle() {
        handle?.visibility = if (prefs.getBoolean("drag", false)) View.VISIBLE else View.GONE
    }

    private fun makeKey(label: String): TextView {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(normal)
            setStroke(dp(2), Color.argb(150, 255, 255, 255))
        }
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 22f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.gravity = Gravity.CENTER
        tv.setTextColor(Color.WHITE)
        tv.background = bg
        tv.layoutParams = LinearLayout.LayoutParams(dp(60), dp(60)).apply {
            setMargins(dp(6), dp(6), dp(6), dp(6))
        }

        var rgb: ValueAnimator? = null
        val grow = Runnable {
            tv.animate().scaleX(1.2f).scaleY(1.2f).setDuration(120).start()
        }

        fun press() {
            if (prefs.getBoolean("rgb", false)) {
                tv.setTextColor(Color.BLACK)
                rgb = ValueAnimator.ofFloat(0f, 360f).apply {
                    duration = 900
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    addUpdateListener {
                        bg.setColor(Color.HSVToColor(floatArrayOf(it.animatedValue as Float, 1f, 1f)))
                    }
                    start()
                }
            } else {
                val c = prefs.getInt("color", Color.WHITE)
                bg.setColor(c)
                tv.setTextColor(if (ColorUtils.calculateLuminance(c) > 0.5) Color.BLACK else Color.WHITE)
            }
            handler.postDelayed(grow, 250)
        }

        fun release() {
            rgb?.cancel()
            rgb = null
            handler.removeCallbacks(grow)
            bg.setColor(normal)
            tv.setTextColor(Color.WHITE)
            tv.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
        }

        tv.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> press()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> release()
            }
            true
        }
        return tv
    }

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        try { root?.let { wm.removeView(it) } } catch (e: Exception) {}
        root = null
        super.onDestroy()
    }
}
